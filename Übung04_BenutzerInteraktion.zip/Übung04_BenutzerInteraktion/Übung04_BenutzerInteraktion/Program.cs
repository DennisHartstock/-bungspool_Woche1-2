﻿////////////////////////////////////////////90////////////////////////////////////////////
using System;

namespace Übung04_BenutzerInteraktion
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
             * 1.Aufgabe: Schreiben Sie ein Programm, das einen Benutzer befragt, 
             *            ob er fortfahren will und seine Antwort "(j)a oder (n)ein"
             *            als Booleschen Wert ausgibt. Um falschen Eingaben (z.B. 'y')
             *            vorzubeugen, soll dem Benutzer ein dreimalige Wiederholung
             *            ermöglicht werden
             *
             */
        }
    }
}
