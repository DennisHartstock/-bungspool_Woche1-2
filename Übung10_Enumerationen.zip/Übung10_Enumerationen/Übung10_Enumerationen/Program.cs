﻿////////////////////////////////////////////90////////////////////////////////////////////
using System;

namespace Übung10_Enumerationen
{
    /*
     * Aufgabe: Deklarieren Sie einen Aufzählungstyp 'Monat', der alle Monate
     *          des Jahres in aufsteigender Reihenfolge auflistet, sowie eine
     *          Enumeration 'Jahreszeit', welche die Namen der vier Jahreszeiten
     *          enthält. Implementieren Sie dazu eine IO-Schnittstelle, bei der ein
     *          Benutzer bei Eingabe eines Jahreszeitenindixes und eines 
     *          Monatsindexes bei Entsprechung die zugehörigen Namen ausgegeben 
     *          bekommt und bei Nichtentsprechung darüber informiert wird.
     */
    class Program
    {
        static void Main(string[] args)
        {
            Console.ReadLine();
        }
    }
}
