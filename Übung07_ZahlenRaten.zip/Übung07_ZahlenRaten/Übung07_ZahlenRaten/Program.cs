﻿////////////////////////////////////////////90////////////////////////////////////////////
using System;

namespace Übung07_ZahlenRaten
{
    /*
     * Aufgabe: Der Benutzer dieser Anwendung soll eine vom System generierte Zufallszahl
     *          zwischen 1 und 100 in maximal 7 Versuchen erraten.
     * 
     *          Dabei sollen als Lösungstipps nach jedem Rateversuch ein entsprechender
     *          Hinweis "zu groß" bzw. "zu klein" ausgegeben werden. Nach 7 Versuchen,
     *          oder bei Eingabe der gesuchten Zahl, soll abgebrochen werden.
     */
    class Program
    {
        static void Main(string[] args)
        {
            Console.ReadLine();
        }
    }
}
